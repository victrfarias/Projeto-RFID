/* ------ Bibliotecas -------- */
#include <WiFi.h>
#include <NTPClient.h> /* https://github.com/arduino-libraries/NTPClient */
#include <SPI.h>
#include <MFRC522.h>
#include <WiFiClientSecure.h>
#include <UniversalTelegramBot.h> /* https://github.com/witnessmenow/Universal-Arduino-Telegram-Bot */

/* -------- SPI configuração do pinos do Leitor----------- */
#define SDA 21 /* Conectado ao pino D5 do ESP32 */
#define RST 4 /* Conectado ao pino VP do ESP32 */
MFRC522 mfrc522(SDA, RST);

/*-------- Configurações de relógio on-line----------- */
WiFiUDP udp;
NTPClient ntp(udp, "a.st1.ntp.br", -3 * 3600, 60000); /*Cria um objeto "NTP" com as configurações.utilizada no Brasil */
String hora;            /* Variável que armazena */


/* -------- Configurações de Wi-Fi----------- */
const char* ssid = "Victor";
const char* password =  "123456789";

/* -------- Token de acesso Telegram----------- */
#define BOTtoken "7661450889:AAE4ktvuad4gU0sC7WwUOBFQFBHP-uB6DK4" /* Token do telegram */


/* -------- LED----------- */
// #define BLUE 2
// #define RED 15

/*------- Variáveis lógicas ---------- */
int i = 0;
String sit ;
unsigned long temp;


/* ------- Registro de Usuários ---------- */
String cartao = "60 84 BC 55";     /*  Insira um valor ID conhecido */
String chaveiro = "60 84 BC 55"; /*Insira um valor de ID conhecido */
int id = 8166171003;
int id2 = 0;


WiFiClientSecure secure_client;
UniversalTelegramBot bot(BOTtoken, secure_client);

void setupWifi()

{ 

  /* BConectando ao Wi-Fi */
  Serial.begin(115200);      /* Transmissão em 115200 */
  delay(2000);               /* Aguarda 2 segundos. */
  Serial.print("Entrou aqui");
  //ntp.begin();               /* Inicia o protocolo NTP */
  Serial.print("Entrou aqui1");
  /* Indica o Wi-Fi ao qual se conectou */
  Serial.print("Conectando ao Wifi: ");
  Serial.println(ssid);

  /* Tenta se Conectar aos valores armazenados em ssid e password */
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED)
  { /* Enquanto estiver desconectado */
    Serial.print(".");
    delay(500);
  }
  ntp.forceUpdate();          /* Atualização do horário */
  Serial.println("");
  Serial.println("Wi-Fi conectado");
  Serial.print("Endereço de IP: ");
  Serial.println(WiFi.localIP());
}

void setup()
{
  Serial.begin(115200);      /* Transmissão em 115200 */
  SPI.begin();               /* Inicia o protocolo SPI */
  mfrc522.PCD_Init();        /* Inicia o Leitor */

  WiFi.begin(ssid, password);
  WiFi.mode(WIFI_MODE_STA);
 
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.println("Connecting to WiFi..");
  }

  Serial.println(WiFi.macAddress());
  Serial.println("Connected to the WiFi network");

  // pinMode(RED, OUTPUT);      /* LED Vermelho */
  // pinMode(BLUE, OUTPUT);     /* LED Verde */

  //setupWifi();
}

void rfid()
{
  secure_client.setInsecure(); // Isso desativa a verificação de certificado
  /* ---------- Armazenando informações ------- */
  String chat_id = String(bot.messages[i].chat_id);/* Armazena o ID */

  String text = bot.messages[i].text; /*Armazena o texto */

  //int NewMessages = bot.getUpdates(bot.last_message_received + 1); /* Atualiza as mensagens */
  Serial.println("passou aqui 2");
  if ( ! mfrc522.PICC_IsNewCardPresent())
  { /* Procura por novos cartões */
    return;
  }

  if ( ! mfrc522.PICC_ReadCardSerial())
  { /* Reenicia a leitura */
    return;
  }

  MFRC522::MIFARE_Key key;
  MFRC522::StatusCode status;
  for (byte i = 0; i < 6; i++) key.keyByte[i] = 0xFF;

  /*---------- Leitura do ID ------- */
  Serial.print("ID do objeto:"); /* Mostra o valor de ID */
  String conteudo = "";

  /* Rotina para despejar a matriz de bytes com os valores hexadecimais na Serial. */
  for (byte i = 0; i < mfrc522.uid.size; i++)
  {
    Serial.print(mfrc522.uid.uidByte[i] < 0x10 ? " 0" : " ");
    Serial.print(mfrc522.uid.uidByte[i], HEX);
    conteudo.concat(String(mfrc522.uid.uidByte[i] < 0x10 ? " 0" : " "));
    conteudo.concat(String(mfrc522.uid.uidByte[i], HEX));
  }

  Serial.println();
  conteudo.toUpperCase(); /* Converte a String em Letras maiúsculas */

  /*---------- Leitura do Nome ------- */
  String conteudo2 = "";
  /* Variável para controlar os blocos de memórias */
  byte block;
  /* Variável para acessar as linhas */
  byte len;
  byte buffer2[18];
  /* Direciona a leitura ao bloco 1 */
  block = 4;
  len = 18;
  status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 4, &key, &(mfrc522.uid));
  status = mfrc522.MIFARE_Read(block, buffer2, &len);
  for (uint8_t i = 0; i < 16; i++) {
    if (buffer2[i] != 32)
    {
      Serial.write(buffer2[i]);

      conteudo2.concat(char(buffer2[i]));

    }
  }
  Serial.println();
  conteudo2.toUpperCase(); /* Converte a String em Letras maiúscula s */

  /* ---------- Leitura do RG ------- */

  String conteudo3 = "";
  byte buffer1[18];
  /* Direciona a leitura ao bloco 1 */
  block = 1;

  status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, 1, &key, &(mfrc522.uid));
  status = mfrc522.MIFARE_Read(block, buffer1, &len);
  for (uint8_t i = 0; i < 16; i++) {
    if (buffer1[i] != 32)
    {
      Serial.write(buffer1[i]);

      conteudo3.concat(char(buffer1[i]));

    }
  }

  Serial.println();
  conteudo3.toUpperCase(); /* Converte a String em Letras maiúsculas */
  if (conteudo.substring(1) == cartao || conteudo.substring(1) == chaveiro)
  {
    //digitalWrite(RED, 1);
    if (conteudo.substring(1) == cartao)
    {
      id = !id;
      if (id == 1)
      {
        sit = "Entrada";

      }
      else
      {
        sit = "Saída";
      }
    }
    if (conteudo.substring(1) == chaveiro)
    {
      id2 = !id2;
      if (id2 == 1)
      {
        sit = "Entrada";

      }
      else
      {
        sit = "Saída";
      }
    }
  }
  else
  {
    Serial.println("Cartão desconhecido");
    //digitalWrite(BLUE, 1);
  }

  /*---------- Transmitindo ao Telegram------- */

  Serial.println("Cartão on"); /* Cartão ON */
  /* Envia ao Telegram o horário, nome e status Entrando */
  String msg = "\nSituação: " + sit;
  msg += "\n Nome: " + conteudo2;
  msg += "\n Horário:" + hora; /* Horário */
  msg += "\n Linha:" + conteudo;
  msg += "\n Turno:" + conteudo3;

  Serial.println("msg = ");
  Serial.println(msg);

  Serial.print("chat_id = ");
  Serial.println(chat_id);

  bot.sendMessage(chat_id, msg, "");
  delay(10);
  // digitalWrite(RED, 0);
  // digitalWrite(BLUE, 0);
  mfrc522.PICC_HaltA();
  mfrc522.PCD_StopCrypto1();
  loop();
}

void loop()
{

  Serial.println("test----------------------");
  delay(3000);
  if (millis() > 1500)
  { /* Cria um intervalo de tempo entre as leituras */
    rfid();
  }

  /* Armazena o horário atual. */
  hora = ntp.getFormattedTime();
}

